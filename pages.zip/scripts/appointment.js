let alertBox = document.getElementById("alertBox");

function handleAppointmentSubmit(){
    // e.preventDefault();
    // alertBox.style.display = "block";
    // alertBox.style.transform = "translateX(-100%)";
    alert("Appointment Booked Successfully");
}