function handleIndustriesFinancialServicesCardClick()
{
    window.location.href = "../pages/industries/financialServices.html";
}

function handleIndustriesConsumernRetailCardClick()
{
    window.location.href = "../pages/industries/consumerRetail.html";

}

function handleIndustriesICTCardClick()
{
    window.location.href = "../pages/industries/ICT.html";

}

function handleIndustrieshealthCardClick()
{
    window.location.href = "../pages/industries/healthcare.html";

}

function handleIndustriesBuildingnConstructionCardClick()
{
    window.location.href = "../pages/industries/building&construction.html";

}

function handleIndustriesTransportationCardClick()
{
    window.location.href = "../pages/industries/transportation.html";

}